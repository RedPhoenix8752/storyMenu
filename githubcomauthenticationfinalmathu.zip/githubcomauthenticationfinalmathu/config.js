import * as firebase from 'firebase'
require('@firebase/firestore')

var firebaseConfig = {
    apiKey: "AIzaSyB4nIDY2W8YyZTXh0jf_hD1uX1AWxzHVFA",
    authDomain: "willy-db-b8352.firebaseapp.com",
    projectId: "willy-db-b8352",
    storageBucket: "willy-db-b8352.appspot.com",
    messagingSenderId: "1080669486619",
    appId: "1:1080669486619:web:f6e568af65b2ad79b802be"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  export default firebase.firestore();