# searchBar
Added search bar to the wily App
